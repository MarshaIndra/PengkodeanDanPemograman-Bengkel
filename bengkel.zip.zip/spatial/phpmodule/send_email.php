<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $no_hp = $_POST["no_hp"];
    $jenis_kendaraan = $_POST["jenis_kendaraan"];
    $lokasi = $_POST["lokasi"];

    $to = "esaamarsha@gmail.com";

    $subject = "Pengajuan Bengkel Online";

    $message = "Nama: $nama\n";
    $message .= "No HP: $no_hp\n";
    $message .= "Jenis Kendaraan: $jenis_kendaraan\n";
    $message .= "Lokasi: $lokasi\n";

    $headers = "From: sender@example.com\r\n";
    $headers .= "Reply-To: sender@example.com\r\n";

    if (mail($to, $subject, $message, $headers)) {
        echo "Email sent successfully.";
    } else {
        echo "Email sending failed.";
    }
} else {
    header("Location: index.html");
    exit;
}
?>
